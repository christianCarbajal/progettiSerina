package it.unibs.ing.fp.lab.TamaZoo;
/**
* @author christian garcia
*
*/

public class MainTama {

	public static void main(String[] args) {
		Gestione gest=new Gestione();
		Informazioni.inizio();
		gest.creazioneTama();
		Informazioni.regole();
		gest.creazioneMenu();
		
		
	}

}
