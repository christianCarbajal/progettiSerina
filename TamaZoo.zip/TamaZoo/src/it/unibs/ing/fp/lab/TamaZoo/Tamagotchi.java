package it.unibs.ing.fp.lab.TamaZoo;

import java.util.StringJoiner;

/**
* @author christian garcia
*
*/

public class Tamagotchi {

	private String nome;
	private double gradoSazieta;
	private double gradoAffettivita;
	private String tipo;

	protected final double INCREMENTO_BISCOTTO = 1.1;
	private final static int DECREMENTO_AFFETTIVITA=4;
	protected final static int DECREMENTO_SAZIETA=2;
	protected static final int MAX_GRADO = 100;
	protected static final int SOGLIA_BASSA=30;
	private static final int SAZIETA_ALTA=90;
	protected static final int MIN_GRADO=0;
	
	/**
	 * � felice
	 * 
	 */
	private static final String STATO_FELICE = " e' felice";
	/**
	 * � infelice
	 */
	private static final String STATO_INFELICE = " e' infelice";
	/**
	 * � morto X.X
	 */
	private static final String STATO_MORTO = " e' morto X.X ";

	public Tamagotchi(String nome, double gradoAffettivita, double gradoSazieta) {
		if (gradoAffettivita <0) {
			throw new IllegalArgumentException("grado affettivo non pu� essere negativo");
		}
		if (gradoSazieta <0) {
			throw new IllegalArgumentException("grado saziet� non pu� essere negativo");
		}

		this.nome = nome;
		this.gradoSazieta = gradoSazieta;
		this.gradoAffettivita = gradoAffettivita;
		this.tipo="normale";
	}

	public String getNome() {
		return nome;
	}

	public double getGradoSazieta() {
		return gradoSazieta;
	}

	public void setGradoSazieta(double gradoSazieta) {
		this.gradoSazieta = gradoSazieta;
	}

	public double getGradoAffettivita() {
		return gradoAffettivita;
	}

	public void setGradoAffettivita(double gradoAffettivita) {
		this.gradoAffettivita = gradoAffettivita;
	}

	public String getTipo() {
		return this.tipo;
	}

	/**
	 * Gestione del grado di affettivit� in base alle carezze ricevute e al numero
	 * consecutivo di volte che l'opzione � stata scelta. Diminuisce il grado di
	 * saziet� di met� delle carezze ricevute
	 * 
	 * @param carezze double
	 * 
	 * 
	 * 
	 */
	public void riceviCarezze(int carezze) {
	
		
		gradoAffettivita = carezze + gradoAffettivita;

		gradoSazieta = gradoSazieta - ((double)carezze / DECREMENTO_SAZIETA);

		if (gradoAffettivita >= MAX_GRADO) {
			gradoAffettivita = MAX_GRADO;
		}

		if (gradoSazieta <= MIN_GRADO) {
			gradoSazieta = MIN_GRADO;
		}

	}

	

	/**
	 * Gestione del grado di saziet� in base ai biscotti ricevuti e alle volte che
	 * l'opzione � stata scelta. Dimuisce il grado di affettivita di un terzo dei
	 * biscotti ricevuti
	 * 
	 * @param biscotti
	 * @author Christian
	 */
	public void riceviBiscotti(int biscotti) {

		for (int i = 1; i <= biscotti && gradoSazieta < MAX_GRADO; i++) {
			gradoSazieta =gradoSazieta * INCREMENTO_BISCOTTO;

		}

		if (gradoSazieta >= MAX_GRADO) {
			gradoSazieta = MAX_GRADO;

		}
		gradoAffettivita = gradoAffettivita - (double)biscotti /DECREMENTO_AFFETTIVITA;
		if (gradoAffettivita <= MIN_GRADO) {
			gradoAffettivita = MIN_GRADO;
		}

	}

	/**
	 * Controlla quando il tamagotchi muore attraverso i valori di saziet� e
	 * affettivit� ritornando true se uno di essi � 0 oppure se il grado di saziet�
	 * � 100, ritorna false altrimenti
	 * 
	 * @return
	 * @author Christian
	 */
	public boolean sonoMorto() {
		if (gradoAffettivita == MIN_GRADO || gradoSazieta == MIN_GRADO || gradoSazieta == MAX_GRADO) {
			return true;
		}

		return false;
	}

	/**
	 * 
	 * Restituisce true se il grado di affettivit� o sazieta � sotto 30 o la sazieta
	 * � sopra i 90
	 * 
	 * @return
	 * @author Christian
	 */
	public boolean sonoTriste() {
		return gradoAffettivita < SOGLIA_BASSA || gradoSazieta > SAZIETA_ALTA || gradoSazieta < SOGLIA_BASSA;
	}
	
	

	@Override
	public String toString() {
		StringJoiner tama = new StringJoiner(" | ", "[ ", " ]");
		tama.add("Nome: " + nome).add(String.format("Grado sazieta: %.2f", gradoSazieta))
				.add(String.format("Grado affettivita: %.2f", gradoAffettivita))
				.add("Stato: " + nome + (sonoMorto() ? STATO_MORTO : sonoTriste() ? STATO_INFELICE : STATO_FELICE));
				
				
		return tama.toString();
	}
	
	
	
}
