package it.unibs.ing.fp.lab.TamaZoo;
/**
 * Tamagotchi la cui affetivita e' sempre al massimo ed e' insensibile alle carezze
* @author christian garcia
*
*/

public class TamaGordo extends Tamagotchi {
private static double affettivita=100;
private String tipo;

	public TamaGordo(String nome, double gradoSazieta) {
		super(nome, affettivita, gradoSazieta);
		this.tipo="gordo";
	}
	public String getTipo() {
		return this.tipo;
	}
	/**
	 * � triste solo se mangia troppo poco
	 */
public boolean sonoTriste() {
	if(getGradoSazieta()<SOGLIA_BASSA)
		return true;
	
	return false;
}
/**
 * Muore solo se il suo livello sazieta raggiunge il minimo
 */
public boolean sonoMorto() {
	if(getGradoSazieta()==MIN_GRADO)
		return true;
	return false;
}
/**
 * Il suo grado di sazieta diminuisce del doppio rispetto agli altri tamagotchi
 */
public void riceviCarezze(int carezze) {
	setGradoSazieta(getGradoSazieta()- (double)carezze);
	if(getGradoSazieta()<0)
		setGradoSazieta(MIN_GRADO);
}

public void riceviBiscotti(int biscotti) {
	for (int i = 1; i <= biscotti && getGradoSazieta() < MAX_GRADO; i++) {
		setGradoSazieta(getGradoSazieta()*INCREMENTO_BISCOTTO);
	}
	
	if(getGradoSazieta()>100)
		setGradoSazieta(MAX_GRADO);
  }

}
