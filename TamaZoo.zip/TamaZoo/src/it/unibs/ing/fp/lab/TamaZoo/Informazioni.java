package it.unibs.ing.fp.lab.TamaZoo;
/**
 * Contiene il saluto iniziale e varie informazioni di base per l'utente
* @author christian garcia
*
*/

public  class Informazioni {
		private final static String SALUTO="Benvenuto nella creazione e gestione dei Tamagotchi!";
		private final static String INTRO="Prima di iniziare a interagire con i tuoi Tamagotchi appena creati alcune regole: ";
		private final static String REG1="Ci sono 3 diversi tipi di Tamagotchi che si potranno generare : normale,triste e gordo.";
		private final static String REG2="Per ogni tipo di Tama le interazioni avranno effetti diversi, e avranno diverso  ciclo di vita";
		private final static String REG3="Le interazioni saranno applicate a tutti i Tama.I Tama che muiono saranno esclusi da successive interazioni";
		private final static String REG4="Se tutti i Tamagotchi moriranno, un opportuno messaggio verra mostrato e il gioco finira'";
		
		public static void inizio() {
			System.out.println(SALUTO);
			System.out.println();
		}
		public static void regole() {
			System.out.println();
			System.out.println(INTRO);
			System.out.println();
			System.out.println(REG1);
			System.out.println(REG2);
			System.out.println(REG3);
			System.out.println(REG4);
		}
		
}
