package it.unibs.fp.lab.tamagotchi;

import java.util.Random;
import java.util.Scanner;
import it.unibs.fp.mylib.*;

/**
 * @author christian garcia
 *
 */

public class Main {
	private static final String lista[] = { "Carezza", "Biscotti" };//voci menu

	private final static int RANGE_CAREZZE = 20;// range per carezze
	private final static int RANGE_BISCOTTI = 10;// range per biscotti

	private static final int MAX_SAZIETA=99;
	private static final int MAX_AFFETTIVITA=99;
	
	private final static String INFO_TAMA="Informazioni tamagotchi: ";

	public static void main(String[] args) {

		MyMenu m = new MyMenu("Cosa vuoi fare?", lista);// creo menu

		Scanner scan = new Scanner(System.in);

		boolean finito = false;
		
		int scelta;
		int stessaScelta = -1;//memorizzo la scelta precedente del utente
		Informazioni.saluto();
		
		Tamagotchi tama = creaTama();
		
		Informazioni.info();// stampa alcune informazioni base sul ciclo di vita e le interazzioni del tagotchi
		
		while (!finito && !tama.sonoMorto()) { 
			m.stampaMenu();// menu scelte
			scelta = scan.nextInt();
			switch (scelta) {
			case 1:

				if (stessaScelta != scelta) {
					tama.resetContatore();
					stessaScelta = scelta;
				}
				tama.riceviCarezze(randCarezze());
				
				System.out.println(INFO_TAMA + tama);
				break;
			case 2:
				if (stessaScelta != scelta) {
					tama.resetContatore();
					stessaScelta = scelta;
				}
				tama.riceviBiscotti(randBiscotti());
				System.out.println(INFO_TAMA + tama);
				break;
			case 0:
				finito = true; 
				break;
			}

		}
		scan.close();//al termine del ciclo del interazzione con l'utente chiudo lo scanner
		if (finito == true)
			Informazioni.addio(tama.getNome()); 
		else
			Informazioni.morto(tama.getNome());
	}

	public static Tamagotchi creaTama() {
		String nome = InputDati.leggiStringaNonVuota("Inserisci il nome del tuo tamagotchi :\n");
		double gradS = InputDati.leggiIntero(
				"Inserisci un valore iniziale di saziet� compreso tra 1 e 99:\n", 1, MAX_SAZIETA);
		double gradA = InputDati.leggiIntero(
				"Inserisci un valore iniziale di affettivit� compreso tra 1 e 99:\n", 1, MAX_AFFETTIVITA);
		return new Tamagotchi(nome, gradA, gradS);
	}
	/**
	 * Metodo che restituisce un numero intero pseudo-casuale compreso tra
	 * 1 e 20 per lo stimolo delle carezze
	 * 
	 *  @return
	 * @author Michela
	 */
	public static int randCarezze() {
		Random rand=new Random();
		int carezze=rand.nextInt(RANGE_CAREZZE) +1;
		System.out.println(carezze);
		return carezze;
		
	}
	/**
	 * Metodo che che restituisce un numero intero pseudo-casuale compreso tra
	 * 1 e 10 per lo stimolo dei biscotti
	 *  @return
	 * @author Michela
	 */
	public static int randBiscotti() {
		Random rand=new Random();
		int biscotti=rand.nextInt(RANGE_BISCOTTI) +1;
		System.out.println(biscotti);
		return biscotti;
	}
	

}
