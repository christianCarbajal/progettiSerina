package it.unibs.fp.lab.tamagotchi;

import java.util.Scanner;
import it.unibs.fp.mylib.*;

/**
 * @author christian garcia
 *
 */

public class Main {
	private static String lista[] = { "Carezza", "Biscotti" };//voci menu

	private final static int RANGE_CAREZZE = 20 - 1;// range per carezze
	private final static int RANGE_BISCOTTI = 10 - 1;// range per biscotti
	private static int rand;

	private static int stessaScelta = -1;//memorizzo la scelta precedente del utente
	
	private final static String INFO_TAMA="Informazioni tamagotchi: ";

	public static void main(String[] args) {

		MyMenu m = new MyMenu("Cosa vuoi fare?", lista);// creo menu

		Scanner scan = new Scanner(System.in);

		boolean finito = false;
		
		int scelta;
		
		Informazioni.saluto();
		
		Tamagotchi tama = creaTama();
		
		Informazioni.info();// stampa alcune informazioni base sul ciclo di vita e le interazzioni del tagotchi
		
		while (!finito && !tama.sonoMorto()) { 
			m.stampaMenu();// menu scelte
			scelta = scan.nextInt();
			switch (scelta) {
			case 1:

				if (stessaScelta != scelta) {
					tama.resetContatore();
					stessaScelta = scelta;
				}

				rand = (int) (Math.random() * RANGE_CAREZZE + 1);
				System.out.println(rand);
				tama.riceviCarezze(rand);
				System.out.println(INFO_TAMA + tama);
				break;
			case 2:
				if (stessaScelta != scelta) {
					tama.resetContatore();
					stessaScelta = scelta;
				}
				rand = (int) (Math.random() * RANGE_BISCOTTI + 1);
				System.out.println(rand);
				tama.riceviBiscotti(rand);
				System.out.println(INFO_TAMA + tama);
				break;
			case 0:
				finito = true; 
				break;
			}

		}
		scan.close();//al termine del ciclo del interazzione con l'utente chiudo lo scanner
		if (finito == true)
			Informazioni.addio(tama.getNome()); 
		else
			Informazioni.morto(tama.getNome());
	}

	public static Tamagotchi creaTama() {
		String nome = InputDati.leggiStringaNonVuota("Inserisci il nome del tuo tamagotchi :\n");
		double gradS = InputDati.leggiDoubleConMinimoMassimo(
				"Inserisci un valore iniziale di saziet� compreso tra 1 e 99(anche con la virgola):\n", 1, 99);
		double gradA = InputDati.leggiDoubleConMinimoMassimo(
				"Inserisci un valore iniziale di affettivit� compreso tra 1 e 99(anche con la virgola):\n", 1, 99);
		return new Tamagotchi(nome, gradA, gradS);
	}

}
