package it.unibs.fp.lab.tamagotchi;

import java.util.StringJoiner;

/**
 * Classe usata per creare un Tamagotchi, contiene i vari metodi per gestire le
 * interazioni con gli stimoli esterni, controlla il ciclo di vita e da informazioni sullo stato
 * attuale del tamagotchi
 * @author christian garcia
 *
 */

public class Tamagotchi {
	
	private String nome;
	private double gradoSazieta;
	private double gradoAffettivita;
	private int cont;// variabile per tenere conto di quante carezze o biscotti consecutivi il tamagotchi riceve
	
	private static final int MAX_GRADO = 100;
	private static final int SOGLIA_BASSA=30;
	private static final int SAZIETA_ALTA=90;
	
	/**
	 * � felice
	 * 
	 */
	private static final String STATO_FELICE = " e' felice";
	/**
	 * � infelice
	 */
	private static final String STATO_INFELICE = " e' infelice";
	/**
	 * � morto X.X
	 */
	private static final String STATO_MORTO = " e' morto X.X ";

	public Tamagotchi(String nome, double gradoAffettivita, double gradoSazieta) {

		this.nome = nome;
		this.gradoSazieta = gradoSazieta;
		this.gradoAffettivita = gradoAffettivita;
	}

	public String getNome() {
		return nome;
	}

	public double getGradoSazieta() {
		return gradoSazieta;
	}

	public void setGradoSazieta(int gradoSazieta) {
		this.gradoSazieta = gradoSazieta;
	}

	public double getGradoAffettivita() {
		return gradoAffettivita;
	}

	public void setGradoAffettivita(int gradoAffettivita) {
		this.gradoAffettivita = gradoAffettivita;
	}

	/**
	 * Metodo per resettare la il contatore degli stimoli consecutivi (quando si
	 * cambia di opzione), siano essi carezze o biscotti, che il tamagotchi riceve
	 * 
	 * @author Christian
	 */
	public void resetContatore() {
		cont = 0;
	}

	/**
	 * Gestione del grado di affettivit� in base alle carezze ricevute e al numero
	 * consecutivo di volte che l'opzione � stata scelta. Diminuisce il grado di
	 * saziet� di met� delle carezze ricevute
	 * 
	 * @param carezze double
	 * @param cont    int
	 * 
	 * 
	 */
	public void riceviCarezze(int carezze) {
		cont = cont + carezze;
		if (cont <= 15) {
			gradoAffettivita = carezze + gradoAffettivita;

		} else if (cont > 15 && cont < 25) {
			gradoAffettivita = (carezze / 2) + gradoAffettivita;// carezze diminuiscono di effetto se fatte piu di 2
																// volte
		} else
			gradoAffettivita = (carezze / 3) + gradoAffettivita; // oltre le 6 carezze di fila(sempre che sia ancora
																	// vivo) diminuiranno di un terzo

		gradoSazieta = gradoSazieta - (carezze / 2);

		if (gradoAffettivita >= MAX_GRADO) {
			gradoAffettivita = MAX_GRADO;
		}

		if (gradoSazieta <= 0) {
			gradoSazieta = 0;
		}

	}
/**
 * Metodo usato per calcolare la percentuale del aumento sazieta iterando in base
 * al numero dei biscotti.La percentuale di aumento varia in base a quanti biscotti a gia ricevuto il tama
 * 
 *  @param perc
 *  @param biscotti
 *  @return
 * @author Chiara
 */
	private double percBiscotti(int perc, int biscotti) {
		for (int i = 1; i <= biscotti && gradoSazieta < MAX_GRADO; i++) {
			gradoSazieta = gradoSazieta + ((gradoSazieta * perc) / 100);

		}
		return gradoSazieta;
	}

	/**
	 * Gestione del grado di saziet� in base ai biscotti ricevuti e alle volte che
	 * l'opzione � stata scelta. Dimuisce il grado di affettivita di un terzo dei
	 * biscotti ricevuti
	 * 
	 * @param biscotti
	 * @author Christian
	 */
	public void riceviBiscotti(int biscotti) {

		cont = cont + biscotti;
		if (cont <= 10) {
			
			gradoSazieta = percBiscotti(10, biscotti);
			
		} else if (cont > 10 && cont < 17) {

			gradoSazieta = percBiscotti(5, biscotti);// diminuisco il l'effetto

		} else {

			gradoSazieta = percBiscotti(3, biscotti);// se ancora vivo il tama, l'effetto sara molto
														// ridotto
		}

		if (gradoSazieta >= MAX_GRADO) {
			gradoSazieta = MAX_GRADO;

		}
		gradoAffettivita = gradoAffettivita - (double)biscotti / 3;
		if (gradoAffettivita <= 0) {
			gradoAffettivita = 0;
		}

	}

	/**
	 * Controlla quando il tamagotchi muore attraverso i valori di saziet� e
	 * affettivit� ritornando true se uno di essi � 0 oppure se il grado di saziet�
	 * � 100, ritorna false altrimenti
	 * 
	 * @return
	 * @author Christian
	 */
	public boolean sonoMorto() {
		if (gradoAffettivita == 0 || gradoSazieta == 0 || gradoSazieta == MAX_GRADO) {
			return true;
		}

		return false;
	}

	/**
	 * 
	 * Restituisce true se il grado di affettivit� o sazieta � sotto 30 o la sazieta
	 * � sopra i 90
	 * 
	 * @return
	 * @author Christian
	 */
	public boolean sonoTriste() {
		return gradoAffettivita < SOGLIA_BASSA || gradoSazieta > SAZIETA_ALTA || gradoSazieta < SOGLIA_BASSA;
	}
	
	/**
	 * Metodo che ritorna uno stato complessivo del benessere dai due stati precedenti di affettivita e sazieta
	 * 
	 *  @return
	 * @author Chiara
	 */
	public double statoComplessivo() {
		double statoComplessivo =(( gradoAffettivita + gradoSazieta) /2);
		if (sonoMorto() == true)
			statoComplessivo = 0; // lo stato si azzera in quanto il tama � morto
		return statoComplessivo;
	}

	@Override
	public String toString() {
		StringJoiner tama = new StringJoiner(" | ", "[ ", " ]");
		tama.add("Nome: " + nome).add(String.format("Grado sazieta: %.2f", gradoSazieta))
				.add(String.format("Grado affettivita: %.2f", gradoAffettivita))
				.add("Stato: " + nome + (sonoMorto() ? STATO_MORTO : sonoTriste() ? STATO_INFELICE : STATO_FELICE))
				.add(String.format("Stato complessivo : %.2f%%" , statoComplessivo() )) ;
				
		return tama.toString();
	}
}
