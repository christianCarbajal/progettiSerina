package it.unibs.fp.lab.tamagotchi;


/**
 * Contiene i vari messaggi che saranno mostrati al utente come il saluto iniziale, quello di addio
 * e quello di morte del tamagotchi in caso avenisse.Contiene inoltre alcune 
 * informazioni sul funzionnamento degli stimoli esterni e del ciclo del vita del tamagotchi
* @author christian garcia
*
*/

public class Informazioni {
	private static final String SALUTO="Ciao e benvenuto!! :D, qui � dove creerai e gestirai il tuo personale Tamagotchi. Per cominciare ti chiediamo di inserire di inserire alcuni dati ";
	private static final String ADDIO="Torna quando vuoi, ";
	private final static String MORTO=" e' morto, sta pi� attento la prossima volta!";
	private final static String REGOLE="\nPrima di cominciare alcune informazioni base!:".toUpperCase();
	private static final String INFO1="1. I gradi di sazieta e affettivita sono massimo 100 e minimo 0, oltre i quali i gradi non potranno ne aumentare ne diminuire";
	private static final String INFO2="2. Le carezze e i biscotti avranno effettivita ridotta se fatte di seguito";
	private static final String INFO3="3. Il tamagotchi muore se la sazieta o l'affetto raggiunge lo 0 oppure quando la sazieta raggiunge il massimo!!";
	private static final String INFO4="4. Il grado di saziet� aumentera un 10% il valore precedente per ogni biscotto fornito(numero casuale) e diminuira di un numero pari a meta delle carezze ricevuto(quando si scegliera carezze)";
	private static final String INFO5="5. Il grado di affettivita aumentera in base alle carezze ricevute e dimiuira un numero pari a un terzo dei biscotti forniti(quando si scegliera l'opzione biscotti)";	
	
	/**
	 * Stampa a video il saluto iniziale 
	 * @author Chritian
	 */
	public static void saluto() {
		System.out.println(SALUTO);
	}
	
	/**
	 * Stampa il messaggio di addio in caso l'utente scelga di uscire(con il tamagotchi ancora vivo)
	 *  @param nome
	 * @author Christian
	 */
	public static void addio(String nome) {
		System.out.println(ADDIO + nome + " ti aspetta!");
	}
	
	/**
	 * Stampa il messaggio della morte del tamagotchi nel caso non si rispettino le
	 * condizione di soppravivenza del tama
	 * @author Christian
	 */
	public static void morto(String nome) {
		System.out.println(nome + MORTO);
	}
	
	/**
	 * Stampa a video alcune informazioni riguardante il ciclo di vita e gli stimoli esterni
	 * @author Titan
	 */
	public static void info() {
		System.out.println(REGOLE);
		System.out.println(INFO1);
		System.out.println(INFO2);
		System.out.println(INFO3);
		System.out.println(INFO4);
		System.out.println(INFO5);
	}
}
