package it.unibs.ing.fp.lab.TamaZoo;
/**
* @author christian garcia
*
*/

public class TamaGordo extends Tamagotchi {
private static double affettivita=100;
private String tipo;

	public TamaGordo(String nome, double gradoSazieta) {
		super(nome, affettivita, gradoSazieta);
		this.tipo="gordo";
	}
	public String getTipo() {
		return this.tipo;
	}
	
public boolean sonoTriste() {
	if(getGradoSazieta()<SOGLIA_BASSA)
		return true;
	
	return false;
}

public boolean sonoMorto() {
	if(getGradoSazieta()==MIN_GRADO)
		return true;
	return false;
}
public void riceviCarezze(int carezze) {
	setGradoSazieta(getGradoSazieta()- (double)carezze);
	if(getGradoSazieta()<0)
		setGradoSazieta(MIN_GRADO);
}

public void riceviBiscotti(int biscotti) {
	for (int i = 1; i <= biscotti && getGradoSazieta() < MAX_GRADO; i++) {
		setGradoSazieta(getGradoSazieta()*INCREMENTO_BISCOTTO);
	}
	
	if(getGradoSazieta()>100)
		setGradoSazieta(MAX_GRADO);
  }

}
