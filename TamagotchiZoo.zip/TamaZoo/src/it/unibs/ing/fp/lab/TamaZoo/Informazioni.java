package it.unibs.ing.fp.lab.TamaZoo;
/**
* @author christian garcia
*
*/

public  class Informazioni {
		private final static String SALUTO="Benvenuto nella creazione e gestione dei Tamagotchi!";
		private final static String INTRO="Prima di iniziare a interagire con i tuoi Tamagotchi appena creati alcune regole: ";
		private final static String REG1="Ci sono 3 diversi tipi di Tamagotchi che verrano creati: normale,triste e gordo";
		private final static String REG2="Per ogni tipo di Tama le interazioni avranno effetti diversi cosi come il loro ciclo di vita";
		private final static String REG3="Le interazioni sarrano applicate a tutti i Tama.I Tama che muiono saranno esclusi da successive interazioni";
		
		public static void inizio() {
			System.out.println(SALUTO);
			System.out.println();
		}
		public static void regole() {
			System.out.println();
			System.out.println(INTRO);
			System.out.println();
			System.out.println(REG1);
			System.out.println(REG2);
			System.out.println(REG3);
		}
		
}
