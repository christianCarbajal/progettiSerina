package it.unibs.ing.fp.lab.TamaZoo;

import java.util.ArrayList;

/**
 * Classe per la gestione dei Tamagotchi creati
 * 
 * 
* @author christian garcia
*
*/

public class RecintoTama {
private ArrayList<Tamagotchi> recinto;

public RecintoTama() {
	recinto=new ArrayList<>();
}
	public void inserisci(Tamagotchi tamagotchi) {
		recinto.add(tamagotchi);
	}
	/**
	 * Controllo se ci sono Tamagotchi rimasti in vita dopo ogni interazione
	 *  @return
	 * 
	 */
	public boolean controlloTamaVivi() {
		
		return recinto.stream().anyMatch(tam-> !tam.sonoMorto());
	}
	/**
	 * Ogni Tama ancora vivo ricevera un certo numero di biscotti
	 * variando il suo grado di sazieta e affettivita a sceonda della specie
	 *  @param biscotti
	 * 
	 */
	public void nutriTama(int biscotti) {
		
	recinto.stream()
	.filter(tam ->!tam.sonoMorto())
	.forEach(tam->{tam.riceviBiscotti(biscotti); System.out.println(tam); });
	}
	/**
	 * Ogni Tama ancora vivo ricevera un certo numero di carezze
	 * variando il suo grado di sazieta e affettivita a sceonda della specie
	 *  @param carezze
	 * 
	 */
	public void acarezzaTama(int carezze) {
		recinto.stream()
		.filter(tam ->!tam.sonoMorto())
		.forEach(tam->{tam.riceviCarezze(carezze); System.out.println(tam); });
	}
	/**
	 * Stampo a video le informazioni iniziali dei Tama appena creati
	 *  
	 * 
	 */
	public void stampaInfoIniziali() {
		recinto.forEach(System.out::println);
	}
}
