package it.unibs.ing.fp.lab.TamaZoo;
import java.util.Random;

import it.unibs.fp.mylib.*;
/**
* @author christian garcia
*
*/

public class Gestione {
	private final static String INIZIARE="Per cominciare inserisci quanti Tamagotchi vuoi creare ";
	private final static String SALUTI="Torna presto i tuoi Tamagotchi ti aspettano!";
	private final static String ESTINTI="Tutti i tuoi Tamagotchi sono morti!";
	private final static String VALORI_INIZIALI="Valori iniziali dei tamagotchi creati: ";
	
	private final static String NOME_TAMA="Inserisci il nome del Tamagotchi: ";
	
	private final static int MAX_VALORE=99;
	private final static int TIPI_TAMA=3;
	
	
	private final static String TIPO_TAMA="Tipo di Tamagotchi creato: ";
	
	
	private final static int MAX_BISCOTTI=8;
	private final static int MAX_CAREZZE=10;
	
	private final static String[] VOCI_MENU= {"Biscotti","Carezze"};
	private final static String TITOLO_MENU="Scegli l'azione da eseguire";
	
	Random rand=new Random();
	
	private RecintoTama recinto=new RecintoTama();
	
	
	/**
	 * Metodo per la creazione dei diversi tipi di Tamagotchi in base al numero 
	 * che l'utente immette
	 *  
	 * 
	 */

	public void creazioneTama() {
		int numeroTama=InputDati.leggiInteroConMinimo(INIZIARE,1);
		int tipoTama;
		Tamagotchi tamagotchi;
		for(int i=0;i<numeroTama;i++) {
			tipoTama=rand.nextInt(TIPI_TAMA);
			//stampaTipo(tipoTama);
			tamagotchi=creaTama(tipoTama);
			System.out.println(TIPO_TAMA + tamagotchi.getTipo());
			recinto.inserisci(tamagotchi);
		}
	System.out.println(VALORI_INIZIALI);
	System.out.println();
	
	recinto.stampaInfoIniziali();
		
	}
	/**
	 * Creazione del menu in cui l'utente scegliera se dare biscotti o carezze ai Tama
	 * 
	 */
	public void creazioneMenu() {
		MyMenu menu=new MyMenu(TITOLO_MENU,VOCI_MENU);
		boolean finito=false;
		int biscotti;
		int carezze;
		
		do {
			int selezione=menu.scegli();
			switch(selezione) {
			case 1:
				biscotti=rand.nextInt(MAX_BISCOTTI)+1;
				recinto.nutriTama(biscotti);
				break;
			case 2:
				carezze=rand.nextInt(MAX_CAREZZE)+1;
				recinto.acarezzaTama(carezze);
				break;
			case 0:
				finito=true;
				System.out.println(SALUTI);
				break;
			}
			if(!recinto.controlloTamaVivi()) {
				finito=true;
				System.out.println(ESTINTI);
			}
			
		}while(!finito);
	}
	
	public Tamagotchi creaTama(int tipologia) {
		String nome=InputDati.leggiStringaNonVuota(NOME_TAMA);
		int affetto;
		int sazieta=rand.nextInt(MAX_VALORE)+1;
		Tamagotchi tam=null;
		switch(tipologia) {
		case 0:
			affetto=rand.nextInt(MAX_VALORE)+1;
			tam=new Tamagotchi(nome,affetto,sazieta);
			break;
		case 1://tamagordo
			tam=new TamaGordo(nome,sazieta);
			break;
		case 2:
			tam=new TamaTriste(nome,sazieta);
			break;
		}
		
		return tam;
		
	}
	
	
	
	
}
