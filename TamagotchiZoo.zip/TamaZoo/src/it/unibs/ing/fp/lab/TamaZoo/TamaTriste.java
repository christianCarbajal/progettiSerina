package it.unibs.ing.fp.lab.TamaZoo;
/**
 * 
 * 
* @author christian garcia
*
*/

public class TamaTriste extends Tamagotchi {
	private static double affettivita=0;
	private String tipo;
	public TamaTriste(String nome, double gradoSazieta) {
		super(nome, affettivita, gradoSazieta);
		this.tipo="infelice";
		
	}
	
	 
	public void riceviCarezze(int carezze) {
		setGradoSazieta(getGradoSazieta()-(double)(carezze/DECREMENTO_SAZIETA));
		if(getGradoSazieta()<MIN_GRADO) {
			setGradoSazieta(MIN_GRADO);
		}
		
	}
	
	public String getTipo() {
		return this.tipo;
	}
	
	public void riceviBiscotti(int biscotti) {
		for (int i = 1; i <= biscotti && getGradoSazieta() < MAX_GRADO; i++) {
			setGradoSazieta(getGradoSazieta()*INCREMENTO_BISCOTTO);
		}
		
		if(getGradoSazieta()>100)
			setGradoSazieta(MAX_GRADO);
	}
	
	public boolean sonoMorto() {
		if  (getGradoSazieta() == MIN_GRADO || getGradoSazieta() == MAX_GRADO) {
			return true;
			}
		return false;
	}
	/**
	 * � sempre triste indipendentemente dai valori si sazieta e affettivita
	 */
	public boolean sonoTriste() {
		return true;
	}
	
}
